from flask import Flask
from flask import render_template
app = Flask(__name__)


@app.route('/')
def main():
    import model

    model.main()
    return "Model Trained and valiated! find results in result.csv"




if __name__== '__main__':
    app.run(debug=True)